using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Renewability
{
	public class Renewability : Mod
	{
		public override void AddRecipes() {


            //Fabrics

			ModRecipe recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Cobweb, 3);
            recipe.AddTile(TileID.Loom);
            recipe.SetResult(ItemID.Rope, 1);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Silk, 4);
            recipe.SetResult(ItemID.Leather, 1);
            recipe.AddTile(TileID.Loom);
            recipe.AddRecipe();

			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Acorn, 3);
            recipe.SetResult(ItemID.Cobweb, 5);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Hay, 7);
            recipe.SetResult(ItemID.Cobweb, 2);
            recipe.AddRecipe();


			//Earthly Materials

			recipe = new ModRecipe(this);
            recipe.AddIngredient(3, 1); //Stone
            recipe.SetResult(424, 2); //Silt
            recipe.AddTile(TileID.WorkBenches);
            recipe.AddRecipe();

			recipe = new ModRecipe(this);
            recipe.AddIngredient(424, 1); //Silt
            recipe.SetResult(169, 2); //Sand
            recipe.AddTile(TileID.WorkBenches);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(424, 1); //Silt
            recipe.AddIngredient(169, 1); //Sand
            recipe.SetResult(2, 3); //Dirt
            recipe.AddTile(TileID.WorkBenches);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(176, 1); //Mud
            recipe.SetResult(133, 2); //Clay
            recipe.AddTile(TileID.WorkBenches);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Wood, 8); //Wood
            recipe.anyWood = true;
            recipe.AddTile(TileID.Furnaces);
            recipe.SetResult(ItemID.Coal, 1); //Coal
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Coal, 1); //Coal
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(3, 8); //Stone
            recipe.AddRecipe();
			
			
			//Tools
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(3, 128);
            recipe.SetResult(ItemID.Sickle, 1);
            recipe.AddRecipe();
			
			//Workstations
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Wood, 12);
            recipe.AddIngredient(3, 6); //Stone
            recipe.anyWood = true;
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(ItemID.Sawmill, 1);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(this);
            recipe.AddIngredient(ItemID.Wood, 20);
            recipe.AddIngredient(3, 40); //Stone
            recipe.anyWood = true;
            recipe.AddIngredient(424, 20); //Silt
            recipe.AddIngredient(169, 40); //Sand
            recipe.AddIngredient(ItemID.Coal, 10); //Coal
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(ItemID.Extractinator, 1);
            recipe.AddRecipe();
			
        }
	}
	
	
}